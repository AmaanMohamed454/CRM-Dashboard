# WooCRM: The Glassmorphism WordPress Dashboard

Welcome to the ultimate WooCommerce CRM solution! This plugin was built from the ground up for the hackathon, precisely tackling the requirements with a heavy emphasis on native database integration and modern aesthetics.

## 🎯 Hackathon Checklist Met:
✅ **CRM Dashboard Page**: Completely customized, overriding the boring default WordPress Admin UI with a full-screen, responsive React-like experience.
✅ **Customer List**: Visually appealing list dynamically fetching `WP_User` data, complete with order history, total LTV (Lifetime Value), and automatic `VIP` tier highlighting.
✅ **Order Tracking Table**: Retrieves live Woocommerce orders. Features clean typography, avatars, and custom badges.
✅ **Status Dropdowns**: Optimistic UI dropdowns directly hooked into `wc_update_order()`. Changing a dropdown visibly triggers a successful database update across the stack via secure WordPress AJAX endpoints.
✅ **Email Workflow Buttons**: "Email" and "Priority" buttons integrated into the Customer view, launching workflow triggers and toast notifications.
✅ **Dark Mode & Tailwind Styling**: Flawlessly configured via Tailwind CDN with bespoke `glassmorphism` panels, radial gradients, staggering CSS keyframe animations, and customized scrollbars.
✅ **Export as WordPress Plugin**: Packaged entirely into two drag-and-drop secure PHP plugins (`woocrm-plugin.php` and `crm-login.php`).

## 🚀 Key Features to Show Judges:
1. **The Login Portal (`[woocrm_auth]`)**: Demonstrate the registration flow using our custom shortcode. Data is securely pushed directly into the `wp_users` table without any external APIs.
2. **Skeleton Loading**: We've programmed a `800ms` skeleton shimmer on data fetch to emulate professional asynchronous app loading states.
3. **Advanced CSS Aesthetics**: Highlight the sticky header, custom blur backdrops, and the smooth hover micro-interactions on the KPI Cards.

### Installation Instructions
1. Download a fresh WordPress instance with WooCommerce activated.
2. Upload `WooCRM-Hackathon-Submission.zip` to your WordPress Plugins folder.
3. Activate the plugin and click the new **"WooCRM"** icon in your left sidebar.
4. Enjoy the magic!
